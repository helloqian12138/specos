export type ChatMessage = {
    role: "system" | "user" | "assistant";
    content: string;
};
export type OpenAIClientOptions = {
    host: string;
    auth: string;
    timeout: number;
};
export declare class OpenAIClient {
    private readonly options;
    constructor(options: OpenAIClientOptions);
    createChatCompletion(input: {
        model: string;
        messages: ChatMessage[];
        temperature?: number;
    }): Promise<string>;
    streamChatCompletion(input: {
        model: string;
        messages: ChatMessage[];
        temperature?: number;
    }, onDelta: (chunk: string) => void | Promise<void>): Promise<string>;
    private request;
}
