import { ProjectConfig, StackConfig } from "./types.js";
export declare const DEFAULT_STACK: StackConfig;
export declare function loadProjectConfig(projectDir: string): Promise<ProjectConfig>;
