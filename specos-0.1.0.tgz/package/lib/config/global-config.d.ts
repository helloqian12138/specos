export type GlobalConfig = {
    host?: string;
    auth?: string;
    model?: string;
    dist?: string;
    timeout?: number;
};
export declare function loadGlobalConfig(): Promise<GlobalConfig>;
export declare function saveGlobalConfig(config: GlobalConfig): Promise<void>;
export declare function getGlobalConfigPath(): string;
