export declare function createLogger(verbose: boolean): {
    step(label: string, message: string): void;
    warn(message: string): void;
    debug(enabled: boolean, label: string, payload: string): void;
    error(message: string): void;
};
