export declare function fileExists(targetPath: string): Promise<boolean>;
export declare function ensureDirectory(targetDir: string): Promise<void>;
export declare function readTextFile(targetPath: string): Promise<string>;
export declare function writeTextFile(targetPath: string, content: string): Promise<void>;
export declare function writeJsonFile(targetPath: string, payload: unknown): Promise<void>;
export declare function listFilesRecursively(rootDir: string, options?: {
    shouldEnterDir?: (dirName: string, absolutePath: string) => boolean;
}): Promise<string[]>;
