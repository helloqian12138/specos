export type ErrorLogEntry = {
    timestamp: string;
    command: string;
    projectDir: string;
    cwd: string;
    error: string;
    flags: Record<string, string | boolean>;
};
export declare function writeProjectErrorLog(entry: ErrorLogEntry): Promise<void>;
export declare function readLatestProjectError(projectDir: string): Promise<ErrorLogEntry | undefined>;
