import { ParsedArgs } from "../cli.js";
export declare function runInitCommand(parsed: ParsedArgs): Promise<void>;
