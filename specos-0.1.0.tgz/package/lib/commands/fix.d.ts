import { ParsedArgs } from "../cli.js";
export declare function runFixCommand(parsed: ParsedArgs): Promise<void>;
