import { ParsedArgs } from "../cli.js";
export declare function runCompileCommand(parsed: ParsedArgs): Promise<void>;
