import { ParsedArgs } from "../cli.js";
export declare function runRunCommand(parsed: ParsedArgs): Promise<void>;
