type ParsedArgs = {
    command?: string;
    positionals: string[];
    flags: Record<string, string | boolean>;
};
export declare function main(argv: string[]): Promise<void>;
export type { ParsedArgs };
