import { ResolvedCompileConfig } from "../config/types.js";
export type GeneratedFile = {
    path: string;
    content: string;
};
export type CompileResult = {
    files: GeneratedFile[];
    warnings: string[];
};
export declare function compileSpecProject(config: ResolvedCompileConfig): Promise<CompileResult>;
