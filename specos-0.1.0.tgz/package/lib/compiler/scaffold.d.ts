export type ManagedScaffoldFile = {
    path: string;
    content: string;
};
export declare function loadManagedScaffoldFiles(projectDir: string, specContext: string): Promise<ManagedScaffoldFile[]>;
export declare function writeDefaultProjectScaffoldFiles(projectDir: string): Promise<void>;
export declare function listManagedScaffoldPaths(): string[];
export declare function shouldUseDevDependency(packageName: string): boolean;
export declare function inferNodePackageVersion(packageName: string): string;
