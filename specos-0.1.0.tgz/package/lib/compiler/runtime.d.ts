import { createLogger } from "../utils/logger.js";
export type RuntimeTarget = "frontend" | "backend";
export type RuntimeFailure = {
    target: RuntimeTarget;
    stage: "install" | "build" | "start" | "probe";
    summary: string;
    command: string;
    output: string;
};
export declare function runRuntimeValidation(input: {
    outDir: string;
    targets: RuntimeTarget[];
    logger: ReturnType<typeof createLogger>;
    debug: boolean;
}): Promise<{
    success: boolean;
    failures: RuntimeFailure[];
}>;
