import { SpecProject } from "./types.js";
export declare function loadSpecProject(projectDir: string, outDir: string): Promise<SpecProject>;
