export type ParsedSpecProject = {
    app?: SpecAppInfo;
    settings: SpecSettingGroup[];
    blocks: SpecBlock[];
    extensionBlocks: SpecBlock[];
    entities: SpecEntity[];
    actions: SpecAction[];
    pages: SpecPage[];
    components: SpecComponent[];
    states: SpecState[];
};
export type SpecAppInfo = {
    label: string;
    description: string;
};
export type SpecSettingGroup = {
    name: string;
    entries: SpecSettingEntry[];
    rawBody: string;
};
export type SpecSettingEntry = {
    key: string;
    value: string;
};
export type SpecBlock = {
    kind: string;
    name?: string;
    qualifier?: string;
    header: string;
    body: string;
    sections: SpecBlockSection[];
};
export type SpecBlockSection = {
    name: string;
    value?: string;
    body: string;
};
export type SpecEntity = {
    name: string;
    fields: string[];
};
export type SpecAction = {
    name: string;
    apiPath?: string;
    inputFields: string[];
    returnFields: string[];
};
export type SpecPage = {
    name: string;
    route: string;
    tables: SpecTable[];
    buttons: string[];
    layouts: string[];
    texts: string[];
    controls: SpecControl[];
    buttonFlows: SpecButtonFlow[];
};
export type SpecTable = {
    stateName: string;
    columns: string[];
};
export type SpecComponent = {
    name: string;
    formFields: string[];
    buttons: string[];
    modalTitles: string[];
    formControls: SpecFormField[];
    submitFlow?: SpecSubmitFlow;
};
export type SpecState = {
    name: string;
    source?: string;
};
export type SpecControl = {
    kind: string;
    name?: string;
    label?: string;
};
export type SpecFormField = {
    name: string;
    control: string;
};
export type SpecButtonFlow = {
    label: string;
    dispatchAction?: string;
    refreshState?: string;
    openModal?: string;
};
export type SpecSubmitFlow = {
    dispatchAction?: string;
    refreshState?: string;
    closeModal: boolean;
};
export declare function parseSpecProject(specContext: string): ParsedSpecProject;
