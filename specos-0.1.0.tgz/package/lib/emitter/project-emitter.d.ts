import type { GeneratedFile } from "../compiler/compile.js";
type EmitInput = {
    outDir: string;
    clean: boolean;
    files: GeneratedFile[];
    metadata: {
        generatedAt: string;
        projectDir: string;
        model: string;
        summary: string;
        warnings: string[];
    };
    promptTrace: Record<string, unknown>;
};
export declare function emitGeneratedProject(input: EmitInput): Promise<void>;
export {};
